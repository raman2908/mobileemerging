package com.example.wordlistsqlstartercode;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

public class WordListAdapter extends RecyclerView.Adapter<WordListAdapter.WordViewHolder> {

    // 🔑 Constants for intent extras
    public static final String EXTRA_ID = "com.example.wordlistsqlstartercode.EXTRA_ID";
    public static final String EXTRA_POSITION = "POSITION";
    public static final String EXTRA_WORD = "WORD";

    private final LayoutInflater mInflater;
    private final Context mContext;
    private final WordListOpenHelper mDB;

    public WordListAdapter(Context context, WordListOpenHelper db) {
        mInflater = LayoutInflater.from(context);
        mContext = context;
        mDB = db;
    }

    @NonNull
    @Override
    public WordViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View itemView = mInflater.inflate(R.layout.item_word, parent, false);
        return new WordViewHolder(itemView);
    }

    @Override
    public void onBindViewHolder(@NonNull WordViewHolder holder, int position) {
        WordItem current = mDB.query(position); // ✅ Fixed: use query, not insert
        holder.wordItemView.setText(current.getWord());

        final WordViewHolder h = holder;

        // 🗑️ DELETE Button behavior
        holder.deleteButton.setOnClickListener(v -> {
            int deleted = mDB.delete(current.getId());
            if (deleted >= 0) {
                notifyItemRemoved(h.getAdapterPosition());
            }
        });

        // 📝 EDIT Button behavior
        holder.editButton.setOnClickListener(v -> {
            Intent intent = new Intent(mContext, EditWordActivity.class);
            intent.putExtra(EXTRA_ID, current.getId());
            intent.putExtra(EXTRA_POSITION, h.getAdapterPosition());
            intent.putExtra(EXTRA_WORD, current.getWord());
            ((Activity) mContext).startActivityForResult(intent, MainActivity.WORD_EDIT);
        });
    }

    @Override
    public int getItemCount() {
        return (int) mDB.count(); // ✅ Dynamic count from DB
    }

    // 💼 ViewHolder with both buttons
    public static class WordViewHolder extends RecyclerView.ViewHolder {
        public final TextView wordItemView;
        public final Button deleteButton;
        public final Button editButton;

        public WordViewHolder(View itemView) {
            super(itemView);
            wordItemView = itemView.findViewById(R.id.word_text);
            deleteButton = itemView.findViewById(R.id.delete_button);
            editButton = itemView.findViewById(R.id.edit_button);
        }
    }
}
