package com.example.wordlistsqlstartercode;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.material.floatingactionbutton.FloatingActionButton;

public class MainActivity extends AppCompatActivity {

    public static final int WORD_EDIT = 1;
    public static final int WORD_ADD = -1;

    private WordListOpenHelper mDB;
    private WordListAdapter mAdapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // 🔌 Initialize the database
        mDB = new WordListOpenHelper(this);

        // 🎛️ Setup RecyclerView
        RecyclerView recyclerView = findViewById(R.id.recyclerView);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));

        // 📦 Connect the adapter
        mAdapter = new WordListAdapter(this, mDB);
        recyclerView.setAdapter(mAdapter);

        // ➕ Launch EditWordActivity when FAB is clicked
        FloatingActionButton fab = findViewById(R.id.fab);
        fab.setOnClickListener(view -> {
            Intent intent = new Intent(MainActivity.this, EditWordActivity.class);
            startActivityForResult(intent, WORD_EDIT);
        });
    }

    @SuppressLint("NotifyDataSetChanged")
    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (requestCode == WORD_EDIT && resultCode == RESULT_OK && data != null) {
            String word = data.getStringExtra(EditWordActivity.EXTRA_REPLY);
            int id = data.getIntExtra(WordListAdapter.EXTRA_ID, -99);

            if (!TextUtils.isEmpty(word)) {
                if (id == WORD_ADD) {
                    mDB.insert(word); // ✅ Now passes the word
                } else if (id >= 0) {
                    mDB.update(id, word); // ✅ Updates existing word
                }
                mAdapter.notifyDataSetChanged();
            } else {
                Toast.makeText(getApplicationContext(),
                        R.string.empty_not_saved,
                        Toast.LENGTH_LONG).show();
            }
        }
    }
}
