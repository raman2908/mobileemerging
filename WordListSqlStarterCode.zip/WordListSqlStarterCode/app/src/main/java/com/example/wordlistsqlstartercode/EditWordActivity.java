package com.example.wordlistsqlstartercode;

import android.content.Intent;
import android.os.Bundle;
import android.widget.EditText;
import androidx.appcompat.app.AppCompatActivity;

public class EditWordActivity extends AppCompatActivity {
    public static final String EXTRA_REPLY = "com.example.wordlistsqlstartercode.REPLY";

    private EditText editWord;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_edit_word);

        editWord = findViewById(R.id.edit_word);

        findViewById(R.id.button_save).setOnClickListener(view -> {
            String word = editWord.getText().toString();
            Intent replyIntent = new Intent();
            replyIntent.putExtra(EXTRA_REPLY, word);
            setResult(RESULT_OK, replyIntent);
            finish();
        });
    }
}



